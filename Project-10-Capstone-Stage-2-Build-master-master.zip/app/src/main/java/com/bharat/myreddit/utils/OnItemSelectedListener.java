package com.bharat.myreddit.utils;

public interface OnItemSelectedListener {

    void onItemSelected(int position);
}
