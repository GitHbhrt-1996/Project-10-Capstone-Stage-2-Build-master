package com.bharat.myreddit.utils;

public interface OnBackPressedListener {
    void onBackPressed();
}
