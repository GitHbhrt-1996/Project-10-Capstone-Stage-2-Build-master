package com.bharat.myreddit.events;

public class HideContentViewerEvent {}
